import { HomeIcon } from "lucide-react";

const Navbar = () => {
    return (
        <main className="w-full h-[72px] bg-background flex justify-around items-center">
            <div className="w-[40px] h-[40px] flex justify-center items-center bg-primary rounded-full">
                <HomeIcon className="w-[20px] h-[20px]" />
            </div>
        </main>
    );
}

export default Navbar;